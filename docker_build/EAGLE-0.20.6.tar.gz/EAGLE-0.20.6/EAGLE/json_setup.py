# TODO: do all json setup here - not in the db creation code
